import UIKit
import Flutter
import FlutterPluginRegistrant

public class IRSdk {
    public lazy var flutterEngine = FlutterEngine(name: "ir_sdk_engine")
    
    public init() {}
    
    public func printLog(){
        print("Hi, This is IR SDK")
    }
    
    public func getVersion() -> String {
        return "0.1.1"
    }
    
    public func showMessage() -> String {
        return "IR SDK is successfully integrated!"
    }
    
    // MARK: - Flutter Engine Methods
    
    public func buildAndRunEngine() {
        print("Building and running Flutter engine...")
        flutterEngine.run()
        GeneratedPluginRegistrant.register(with: self.flutterEngine)
        print("Flutter engine is ready!")
    }
    
    public func getFlutterViewController() -> FlutterViewController {
        print("Creating Flutter view controller...")
        return FlutterViewController(engine: flutterEngine, nibName: nil, bundle: nil)
    }
    
    public func restartEngine() {
        print("Restarting Flutter engine...")
        flutterEngine.destroyContext()
        buildAndRunEngine()
    }
}

